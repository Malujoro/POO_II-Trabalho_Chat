from worker.worker import Worker
from worker.postgresSQL import PostgressDB
from worker.redis_bd import RedisDB