# Define o endereço e porta do servidor
HOST = '10.180.45.67'
PORT = 7000
ADDR = (HOST, PORT)

nome_admin = "funcionario"
nome_cliente = "usuario"
total_usuarios = 2
