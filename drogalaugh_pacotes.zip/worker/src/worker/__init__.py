from worker.worker import Worker
from worker.postgresSQL import PostgressDB
from worker.redis_bd import RedisDB

"""
Importações:

1. Importa a classe Worker
2. Importa a classe PostgressDB
3. Importa a classe RedisDB
"""
