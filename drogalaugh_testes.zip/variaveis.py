# Define o endereço e porta do servidor
HOST = '127.0.0.1'
PORT = 7000
ADDR = (HOST, PORT)

nome_admin = "funcionario"
nome_cliente = "usuario"
total_usuarios = 2