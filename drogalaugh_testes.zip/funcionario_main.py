from user_class import *

if(__name__ == "__main__"):
    admin = User(nome_admin)
    admin.iniciar()