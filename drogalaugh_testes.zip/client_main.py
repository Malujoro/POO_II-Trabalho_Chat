from user_class import *

if(__name__ == "__main__"):
    cliente = User(nome_cliente, 300)
    cliente.iniciar()